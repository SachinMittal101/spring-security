package com.test.secureapp;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyConntroller {

	@GetMapping(value = "/ping")
	public String ping() {
		return "pong";
	}
	
}
